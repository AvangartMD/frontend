import React from "react";

class Index extends React.Component {
  render() {
    return (
      <>
        <a href="/login">
          <h4>Login</h4>
        </a>
        <br />
      </>
    );
  }
}

export default Index;
