import React from "react";


class Index extends React.Component {

    render() {

        return(
            <>
                minting nft's
            </>
        )
    }
}

export default Index;