import React from "react";

class Index extends React.Component {

    render() {

        return(
            <>
                footer html
            </>
        )
    }
}

export default Index;