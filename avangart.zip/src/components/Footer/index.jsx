import React from "react";

class Index extends React.Component {

    render() {

        return(
            <>
                
            </>
        )
    }
}

export default Index;