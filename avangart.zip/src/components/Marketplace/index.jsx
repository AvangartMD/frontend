import React from "react";


class Index extends React.Component {

    render() {

        return(
            <>
                marketplace page
            </>
        )
    }
}

export default Index;