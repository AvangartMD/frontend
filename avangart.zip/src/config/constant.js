var CONSTANT = function () {};

CONSTANT.PROFFESIONALTIER = 5000;
CONSTANT.legendary_APYMultiplier = 6;
CONSTANT.professional_APYMultiplier = 3;
CONSTANT.rookie_APYMultiplier = 1;
CONSTANT.liquidity_APYMultiplier = 1;

module.exports = CONSTANT;
